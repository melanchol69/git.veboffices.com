dofile("/banking/scripts/welcome.lua")
return